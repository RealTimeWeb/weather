WeatherService
=======

Python port in progress